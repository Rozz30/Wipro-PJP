package com.wipro.automobile.ship;

public class Solution {

	public static void main(String[] args) {
		Compartment compartment = new Compartment(1105.15, 500.5, 600.2);
		
		System.out.println(compartment);
	}

}
